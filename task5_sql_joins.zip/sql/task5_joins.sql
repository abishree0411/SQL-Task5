
-- Create Tables
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    CustomerName TEXT,
    City TEXT
);

CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    CustomerID INT,
    OrderDate TEXT,
    Amount REAL,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Insert Customers
INSERT INTO Customers VALUES (1, 'Alice', 'Delhi');
INSERT INTO Customers VALUES (2, 'Bob', 'Mumbai');
INSERT INTO Customers VALUES (3, 'Charlie', 'Chennai');
INSERT INTO Customers VALUES (4, 'David', 'Kolkata');

-- Insert Orders
INSERT INTO Orders VALUES (101, 1, '2024-06-01', 500.00);
INSERT INTO Orders VALUES (102, 2, '2024-06-02', 300.00);
INSERT INTO Orders VALUES (103, 1, '2024-06-05', 150.00);
INSERT INTO Orders VALUES (104, 5, '2024-06-06', 250.00);  -- No matching customer

-- INNER JOIN
SELECT Customers.CustomerID, CustomerName, OrderID, Amount
FROM Customers
INNER JOIN Orders ON Customers.CustomerID = Orders.CustomerID;

-- LEFT JOIN
SELECT Customers.CustomerID, CustomerName, OrderID, Amount
FROM Customers
LEFT JOIN Orders ON Customers.CustomerID = Orders.CustomerID;

-- RIGHT JOIN (emulated in SQLite using reversed LEFT JOIN)
SELECT Orders.CustomerID, CustomerName, OrderID, Amount
FROM Orders
LEFT JOIN Customers ON Customers.CustomerID = Orders.CustomerID;

-- FULL OUTER JOIN (simulated using UNION of LEFT and RIGHT JOINs)
SELECT Customers.CustomerID, CustomerName, OrderID, Amount
FROM Customers
LEFT JOIN Orders ON Customers.CustomerID = Orders.CustomerID
UNION
SELECT Orders.CustomerID, CustomerName, OrderID, Amount
FROM Orders
LEFT JOIN Customers ON Customers.CustomerID = Orders.CustomerID;
